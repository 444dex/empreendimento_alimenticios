import tkinter as tk
import tkinter.ttk as ttk
import mysql.connector
from db import conectar
from tkinter import messagebox
from PIL import Image, ImageTk 

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de Empreendimento Alimentício")
        self.geometry("800x500")
        self.configure(bg="#f5f5f5")
        self.frames = {}

        telas = {
            "BoasVindas": TelaBoasVindas,
            "Login": TelaLogin,
            "Cadastro": TelaCadastro,
            "DashboardCliente": TelaDashboardCliente,
            "DashboardAdmin": TelaDashboardAdmin,
            "Produtos": TelaProdutos,
            "Pedidos": TelaPedidos,
            "Relatorios": TelaRelatorios,
            "Sugestoes": TelaSugestoes,
            "Categorias": TelaCategorias,
            "Configuracoes": TelaConfiguracoes,
            "Ajuda": TelaAjuda,
        }

        for nome, Tela in telas.items():
            frame = Tela(self)
            self.frames[nome] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.mostrar_tela("BoasVindas")

    def mostrar_tela(self, nome):
        frame = self.frames[nome]
        frame.tkraise()


def carregar_imagem(caminho, largura, altura):
    img = Image.open(caminho)
    img = img.resize((largura, altura), Image.Resampling.LANCZOS)
    return ImageTk.PhotoImage(img)


# ================= TELAS ====================

class TelaBoasVindas(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#ffffff")
        logo = carregar_imagem("logo.png", 200, 200)
        tk.Label(self, image=logo, bg="#ffffff").pack(pady=20)
        self.logo = logo
        tk.Label(self, text="Bem-vindo ao Sistema do Empreendimento Alimentício!",
                 font=("Arial", 20, "bold"), bg="#ffffff").pack(pady=10)
        tk.Button(self, text="Entrar", font=("Arial", 14), bg="#6200ee", fg="white",
                  command=lambda: master.mostrar_tela("Login")).pack(pady=20)


class TelaLogin(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#f5f5f5")
        tk.Label(self, text="Login", font=("Arial", 20, "bold"), bg="#f5f5f5").pack(pady=10)

        tk.Label(self, text="Email:", bg="#f5f5f5").pack()
        self.entry_email = tk.Entry(self)
        self.entry_email.pack(pady=5)

        tk.Label(self, text="Senha:", bg="#f5f5f5").pack()
        self.entry_senha = tk.Entry(self, show="*")
        self.entry_senha.pack(pady=5)

        tk.Button(self, text="Entrar", bg="#03dac6", fg="black",
                  command=self.login).pack(pady=5)
        tk.Button(self, text="Cadastrar Novo Usuário", bg="#6200ee", fg="white",
                  command=lambda: master.mostrar_tela("Cadastro")).pack(pady=5)

    def login(self):
        email = self.entry_email.get()
        senha = self.entry_senha.get()
        user = self.verificar_login(email, senha)

        if user:
            if user["tipo"] == "cliente":
                self.master.mostrar_tela("DashboardCliente")
            else:
                self.master.mostrar_tela("DashboardAdmin")
        else:
            messagebox.showerror("Erro", "Usuário ou senha incorretos!")

    @staticmethod
    def verificar_login(email, senha):
        conn = conectar()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM usuarios WHERE email=%s AND senha=%s", (email, senha))
        user = cursor.fetchone()
        conn.close()
        return user


class TelaCadastro(tk.Frame):
    def cadastrar_usuario(self):
        nome = self.entry_nome.get()
        email = self.entry_email.get()
        senha = self.entry_senha.get()

        try:
            conn = conectar()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (%s, %s, %s, %s)",
                           (nome, email, senha, "cliente"))
            conn.commit()
            conn.close()
            messagebox.showinfo("Sucesso", "Usuário cadastrado com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao cadastrar: {e}")

    def __init__(self, master):
        super().__init__(master, bg="#ffffff")

        tk.Label(self, text="Cadastro de Usuário", font=("Arial", 18, "bold"), bg="#ffffff").pack(pady=10)
        
        tk.Label(self, text="Nome:", bg="#ffffff").pack()
        self.entry_nome = tk.Entry(self)
        self.entry_nome.pack(pady=5)

        tk.Label(self, text="Email:", bg="#ffffff").pack()
        self.entry_email = tk.Entry(self)
        self.entry_email.pack(pady=5)

        tk.Label(self, text="Senha:", bg="#ffffff").pack()
        self.entry_senha = tk.Entry(self, show="*")
        self.entry_senha.pack(pady=5)

        tk.Button(self, text="Registrar", bg="#03dac6", fg="black",
                  command=self.cadastrar_usuario).pack(pady=5)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("Login")).pack(pady=5)


class TelaDashboardCliente(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#f5f5f5")
        tk.Label(self, text="Painel do Cliente", font=("Arial", 18, "bold"), bg="#f5f5f5").pack(pady=10)

        tk.Button(self, text="📦 Fazer Pedido", command=lambda: master.mostrar_tela("Pedidos")).pack(pady=5)
        tk.Button(self, text="🍔 Ver Cardápio", command=lambda: master.mostrar_tela("Produtos")).pack(pady=5)
        tk.Button(self, text="📊 Meus Pedidos", command=lambda: master.mostrar_tela("Relatorios")).pack(pady=5)


class TelaDashboardAdmin(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#f5f5f5")
        tk.Label(self, text="Painel Administrativo", font=("Arial", 18, "bold"), bg="#f5f5f5").pack(pady=10)

        tk.Button(self, text="➕ Cadastrar Produto", command=lambda: master.mostrar_tela("Produtos")).pack(pady=5)
        tk.Button(self, text="📂 Categorias", command=lambda: master.mostrar_tela("Categorias")).pack(pady=5)
        tk.Button(self, text="📊 Relatórios de Vendas", command=lambda: master.mostrar_tela("Relatorios")).pack(pady=5)
        tk.Button(self, text="💡 Sugestões de Gestão", command=lambda: master.mostrar_tela("Sugestoes")).pack(pady=5)
        tk.Button(self, text="⚙️ Configurações", command=lambda: master.mostrar_tela("Configuracoes")).pack(pady=5)


class TelaProdutos(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#ffffff")

        tk.Label(self, text="Cadastro de Produtos", font=("Arial", 16, "bold"), bg="#ffffff").pack(pady=10)

        # Entradas
        tk.Label(self, text="Nome do Produto:", bg="#ffffff").pack()
        self.entry_nome = tk.Entry(self)
        self.entry_nome.pack(pady=5)

        tk.Label(self, text="Preço:", bg="#ffffff").pack()
        self.entry_preco = tk.Entry(self)
        self.entry_preco.pack(pady=5)

        tk.Button(self, text="Salvar Produto", bg="#03dac6", fg="black",
                  command=self.salvar_produto).pack(pady=5)

        # Tabela de Produtos
        self.tree = ttk.Treeview(self, columns=("id", "nome", "preco", "estoque"), show="headings")
        self.tree.heading("id", text="ID")
        self.tree.heading("nome", text="Nome")
        self.tree.heading("preco", text="Preço")
        self.tree.heading("estoque", text="Estoque")
        self.tree.pack(fill="both", expand=True, pady=10)

        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardAdmin")).pack(pady=5)

        # Carregar dados ao abrir a tela
        self.carregar_produtos()

    def salvar_produto(self):
        nome = self.entry_nome.get()
        preco = self.entry_preco.get()

        try:
            conn = conectar()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO produtos (nome, preco, estoque, categoria_id) VALUES (%s, %s, %s, %s)",
                           (nome, preco, 10, 1))  # estoque inicial 10, categoria 1 só como exemplo
            conn.commit()
            conn.close()
            messagebox.showinfo("Sucesso", "Produto cadastrado!")
            self.carregar_produtos()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def carregar_produtos(self):
        # Limpa tabela antes de recarregar
        for item in self.tree.get_children():
            self.tree.delete(item)

        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT id, nome, preco, estoque FROM produtos")
        for row in cursor.fetchall():
            self.tree.insert("", "end", values=row)
        conn.close()

class TelaPedidos(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#ffffff")
        tk.Label(self, text="Cadastro de Pedido", font=("Arial", 16, "bold"), bg="#ffffff").pack(pady=10)
        tk.Entry(self).pack(pady=5)
        tk.Button(self, text="Finalizar Pedido", bg="#ff0266", fg="white",
                  command=lambda: messagebox.showinfo("OK", "Pedido realizado!")).pack(pady=5)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardCliente")).pack(pady=5)


class TelaRelatorios(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#f5f5f5")
        tk.Label(self, text="Relatórios de Vendas e Estoque", font=("Arial", 16, "bold"), bg="#f5f5f5").pack(pady=10)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardAdmin")).pack(pady=5)


class TelaSugestoes(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#f5f5f5")
        tk.Label(self, text="Sugestões de Gestão", font=("Arial", 16, "bold"), bg="#f5f5f5").pack(pady=10)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardAdmin")).pack(pady=5)


class TelaCategorias(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#ffffff")
        tk.Label(self, text="Gerenciamento de Categorias de Produtos", font=("Arial", 16, "bold"), bg="#ffffff").pack(pady=10)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardAdmin")).pack(pady=5)


class TelaConfiguracoes(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#ffffff")
        tk.Label(self, text="Configurações do Sistema", font=("Arial", 16, "bold"), bg="#ffffff").pack(pady=10)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardAdmin")).pack(pady=5)


class TelaAjuda(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#ffffff")
        tk.Label(self, text="Ajuda e Suporte", font=("Arial", 16, "bold"), bg="#ffffff").pack(pady=10)
        tk.Button(self, text="Voltar", bg="#cccccc",
                  command=lambda: master.mostrar_tela("DashboardAdmin")).pack(pady=5)


# =============== MAIN =================
if __name__ == "__main__":
    app = App()
    app.mainloop()
